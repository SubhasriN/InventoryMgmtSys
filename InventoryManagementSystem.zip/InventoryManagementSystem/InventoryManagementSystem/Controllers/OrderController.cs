﻿using InventoryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace InventoryManagementSystem.Controllers
{
    public class OrderController : Controller
    {
        private readonly InMemoryDatabase _db;

        public OrderController(InMemoryDatabase db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            var ordersWithProducts = _db.Orders.Select(order => new
            {
                order.Id,
                order.ProductId,
                order.Quantity,
                order.OrderPrice,
                order.OrderDate,
                ProductName = _db.Products.FirstOrDefault(p => p.Id == order.ProductId)?.Name
            }).ToList();

            return View(ordersWithProducts);
        }

        public IActionResult Create()
        {
            ViewBag.Products = _db.Products.Where(p => p.Stock > 0).ToList();
            return View();
        }

        [HttpPost]
        public IActionResult Create(int productId, int quantity)
        {            
            var product = _db.Products.FirstOrDefault(p => p.Id == productId);
            if (product.Stock < quantity)
            {
                ModelState.AddModelError("Quantity", "Insufficient stock");
                ViewBag.Products = _db.Products.Where(p => p.Stock > 0).ToList();
                return View();
            }
         
            product.Stock -= quantity;

            var order = new Order
            {
                Id = _db.Orders.Count + 1,
                ProductId = productId,
                Quantity = quantity,
                OrderPrice= quantity * product.Price
            };

            _db.Orders.Add(order);
            return RedirectToAction(nameof(Index));
        }
        public IActionResult Report()
        {
            // Calculate the total revenue by multiplying product price by quantity sold
            var totalRevenue = _db.Orders.Sum(order =>
            {
                var product = _db.Products.FirstOrDefault(p => p.Id == order.ProductId);
                return product != null ? product.Price * order.Quantity : 0;
            });

            ViewData["TotalRevenue"] = totalRevenue;
            return View();
        }
    }
}
