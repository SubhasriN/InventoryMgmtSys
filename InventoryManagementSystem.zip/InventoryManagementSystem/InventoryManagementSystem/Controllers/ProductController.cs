﻿using System.Text.RegularExpressions;
using InventoryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace InventoryManagementSystem.Controllers
{
    public class ProductController : Controller
    {
        private readonly InMemoryDatabase _db;

        public ProductController(InMemoryDatabase db)
        {
            _db = db;
        }

        public IActionResult Index()
        {
            return View(_db.Products);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Product product)
        {
            if (_db.Products.Any(p => p.Name == product.Name))
            {
                ModelState.AddModelError("Name", "A product with this name already exists.");
                return View(product);
            }

            if (!ModelState.IsValid) return View(product);

            //product.Id = _db.Products.Count + 1;
            var nextId = _db.Products.Any() ? _db.Products.Max(p => p.Id) + 1 : 1;
            product.Id = nextId;

            _db.Products.Add(product);

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Edit(int id)
        {
            var product = _db.Products.FirstOrDefault(p => p.Id == id);
            if (product == null) return NotFound();

            return View(product);
        }

        [HttpPost]
        public IActionResult Edit(Product product)
        {
            if (!ModelState.IsValid) return View(product);

            var existingProduct = _db.Products.FirstOrDefault(p => p.Id == product.Id);
            if (existingProduct == null) return NotFound();

            existingProduct.Name = product.Name;
            existingProduct.Price = product.Price;
            existingProduct.Stock = product.Stock;

            return RedirectToAction(nameof(Index));
        }

        public IActionResult Delete(int id)
        {
            var product = _db.Products.FirstOrDefault(p => p.Id == id);
            if (product == null) return NotFound();

            _db.Products.Remove(product);
            return RedirectToAction(nameof(Index));
        }
    }
}
