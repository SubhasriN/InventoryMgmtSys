﻿using InventoryManagementSystem.Models;

namespace InventoryManagementSystem
{
    public class InMemoryDatabase
    {
        public List<Product> Products { get; set; } = [];
        public List<Order> Orders { get; set; } = [];
    }

}
